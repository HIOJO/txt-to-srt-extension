
document.getElementById('convertButton').addEventListener('click', async function() {
    let fileInput = document.getElementById('fileInput');
    if (!fileInput.files.length) {
        alert("Please select a text file.");
        return;
    }

    let file = fileInput.files[0];
    let reader = new FileReader();

    reader.onload = async function(event) {
        let textContent = event.target.result;

        // Seleção da voz
        let voiceId = document.getElementById('voiceSelect').value;

        // Converte o texto em voz usando a API da OpenAI
        let audioUrl = await textToSpeech(textContent, voiceId);
        
        if (audioUrl) {
            let audioPlayer = document.getElementById('audioPlayer');
            audioPlayer.src = audioUrl;
        } else {
            alert("Error generating speech.");
        }
    };

    reader.readAsText(file);
});

// Função para converter texto em voz usando a API da OpenAI
async function textToSpeech(text, voiceId) {
    try {
        const response = await fetch('https://api.openai.com/v1/speech-to-text', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer YOUR_OPENAI_API_KEY`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                text: text,
                voice: voiceId
            })
        });

        const data = await response.json();
        if (data.audio_url) {
            return data.audio_url;
        } else {
            console.error("API response error:", data);
            return null;
        }
    } catch (error) {
        console.error("Request failed:", error);
        return null;
    }
}

// Popula a lista de vozes disponíveis
document.addEventListener('DOMContentLoaded', async function() {
    const voices = await fetchAvailableVoices();
    let voiceSelect = document.getElementById('voiceSelect');

    voices.forEach(voice => {
        let option = document.createElement('option');
        option.value = voice.id;
        option.textContent = voice.name;
        voiceSelect.appendChild(option);
    });
});

async function fetchAvailableVoices() {
    // Exemplo de vozes estáticas, deve ser atualizado com vozes reais da API
    return [
        { id: 'voice1', name: 'Voice 1' },
        { id: 'voice2', name: 'Voice 2' }
    ];
}
